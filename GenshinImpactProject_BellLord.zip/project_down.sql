DROP PROCEDURE characters_by_element;
DROP PROCEDURE search_item;
DROP PROCEDURE search_enemy;
DROP PROCEDURE search_elite;
DROP PROCEDURE search_domain;
DROP PROCEDURE search_character;

DROP TABLE Character_Rewards;
DROP TABLE Elite_Rewards;
DROP TABLE Enemy_Rewards;
DROP TABLE Domain_Rewards;
DROP TABLE Characters;
DROP TABLE Enemies;
DROP TABLE Elites;
DROP TABLE Domains;
DROP TABLE Rewards;